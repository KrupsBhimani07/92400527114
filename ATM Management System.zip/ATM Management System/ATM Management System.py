import json
import os
import random
import datetime
import tkinter as tk
from tkinter import messagebox
import time
import winsound
import matplotlib.pyplot as plt

# ---------- VOICE ----------
try:
    import pyttsx3
    engine = pyttsx3.init('sapi5')
    engine.setProperty('rate', 150)
    VOICE_AVAILABLE = True
except:
    engine = None
    VOICE_AVAILABLE = False

def speak(text):
    try:
        if VOICE_AVAILABLE and engine:
            engine.say(text)
            engine.runAndWait()
        else:
            print("🔊:", text)
    except:
        print("🔊:", text)

# ---------- FORMAT ----------
def format_money(amount):
    return "₹{:,.0f}".format(amount)

# ---------- FILES ----------
USERS_FILE = "users.json"
ATM_FILE = "atm_cash.json"
ADMIN_USER = "krupal7114"
ADMIN_PASS = "2007"

# ---------- DATA ----------
def load_data(file):
    if not os.path.exists(file):
        with open(file, "w") as f:
            json.dump({}, f)
    with open(file, "r") as f:
        return json.load(f)

def save_data(file, data):
    with open(file, "w") as f:
        json.dump(data, f, indent=4)

def current_time():
    return datetime.datetime.now().strftime("%d-%m-%Y %I:%M:%S %p")

# ---------- SOUND ----------
def pin_sound():
    try:
        winsound.PlaySound("Pin.wav", winsound.SND_FILENAME | winsound.SND_ASYNC)
    except:
        pass

def withdraw_sound():
    try:
        winsound.PlaySound("withdraw.wav", winsound.SND_FILENAME)
    except:
        pass

# ---------- GRAPH ----------
def show_graph(users):
    total_deposit = 0
    total_withdraw = 0

    for user in users.values():
        for txn in user["transactions"]:
            if txn["type"] == "Deposit":
                total_deposit += txn["amount"]
            elif txn["type"] == "Withdraw":
                total_withdraw += txn["amount"]

    labels = ["Deposit","Withdraw"]
    values = [total_deposit,total_withdraw]

    plt.figure()
    plt.bar(labels, values)
    plt.title("Total Deposit vs Withdraw")

    for i, v in enumerate(values):
        plt.text(i, v, str(v), ha='center')

    plt.show()

def show_pie_chart(atm_cash):
    labels = list(atm_cash.keys())
    sizes = list(atm_cash.values())

    plt.figure()
    plt.pie(sizes, labels=labels, autopct='%1.1f%%')
    plt.title("ATM Cash Distribution")
    plt.show()

# ---------- LOADING ----------
def loading_bar():
    win = tk.Toplevel(root)
    win.title("Processing")
    win.geometry("300x120")
    win.configure(bg="black")

    tk.Label(win, text="Processing...", fg="white", bg="black").pack(pady=10)
    canvas = tk.Canvas(win, width=250, height=20, bg="white")
    canvas.pack()

    bar = canvas.create_rectangle(0, 0, 0, 20, fill="green")

    for i in range(0, 251, 5):
        canvas.coords(bar, 0, 0, i, 20)
        win.update()
        time.sleep(0.01)

    return win

# ---------- CASH ANIMATION ----------
def cash_animation():
    anim = tk.Toplevel(root)
    anim.title("Cash Dispensing")
    anim.geometry("300x200")
    anim.configure(bg="black")

    lbl = tk.Label(anim, text="💸", font=("Arial",30), bg="black", fg="yellow")
    lbl.pack(expand=True)

    for i in range(10):
        lbl.config(text="💸 " * (i+1))
        anim.update()
        time.sleep(0.1)

    return anim

# ---------- CARD SWIPE ----------
def card_swipe_animation(callback):
    win = tk.Toplevel(root)
    win.title("Insert Card")
    win.geometry("400x200")
    win.configure(bg="black")

    tk.Label(win, text="👉 Insert Your Card", fg="white", bg="black", font=("Arial",16)).pack(pady=20)

    canvas = tk.Canvas(win, width=300, height=80, bg="black", highlightthickness=0)
    canvas.pack()

    card = canvas.create_rectangle(10,20,110,60, fill="blue")

    for i in range(200):
        canvas.move(card, 1, 0)
        win.update()
        time.sleep(0.005)

    win.destroy()
    callback()

# ---------- ATM ----------
class ATM:
    def __init__(self):
        self.users = load_data(USERS_FILE)
        self.cash = load_data(ATM_FILE)
        self.current_user = None

        if not self.cash:
            self.cash = {"2000":50,"500":100,"200":100,"100":200}
            save_data(ATM_FILE, self.cash)

    def create_user(self, name, pin, balance):
        card = str(random.randint(10**11, 10**12 - 1))
        self.users[card] = {
            "name": name,
            "pin": pin,
            "balance": balance,
            "transactions":[
                {"date":current_time(),"type":"Deposit","amount":balance,"balance_after":balance}
            ]
        }
        save_data(USERS_FILE, self.users)
        return card

    def login(self, card, pin):
        if card in self.users and self.users[card]["pin"] == pin:
            self.current_user = card
            return True
        return False

    def deposit(self, amount):
        user = self.users[self.current_user]
        user["balance"] += amount
        user["transactions"].append({
            "date": current_time(),
            "type": "Deposit",
            "amount": amount,
            "balance_after": user["balance"]
        })
        save_data(USERS_FILE, self.users)

    def withdraw(self, amount):
        user = self.users[self.current_user]
        if amount > user["balance"]:
            return False
        user["balance"] -= amount
        user["transactions"].append({
            "date": current_time(),
            "type": "Withdraw",
            "amount": amount,
            "balance_after": user["balance"]
        })
        save_data(USERS_FILE, self.users)
        return True

    def get_balance(self):
        return self.users[self.current_user]["balance"]

    def get_user(self):
        return self.users[self.current_user]

atm = ATM()

# ---------- GUI ----------
root = tk.Tk()
root.title("REAL ATM")
root.attributes("-fullscreen", True)
root.configure(bg="black")

def clear():
    for w in root.winfo_children():
        w.destroy()

def title(text):
    tk.Label(root,text=text,font=("Arial",28,"bold"),bg="black",fg="cyan").pack(pady=20)

def label(text):
    tk.Label(root,text=text,font=("Arial",14),bg="black",fg="white").pack()

# ---------- KEYPAD ----------
def keypad(entry):
    frame = tk.Frame(root, bg="black")
    frame.pack()

    def press(num):
        entry.insert("end", str(num))
        pin_sound()

    def clear_entry():
        entry.delete(0, 'end')

    nums = [('1',1,0),('2',1,1),('3',1,2),
            ('4',2,0),('5',2,1),('6',2,2),
            ('7',3,0),('8',3,1),('9',3,2),
            ('0',4,1)]

    for (t,r,c) in nums:
        tk.Button(frame,text=t,width=5,height=2,
                  command=lambda x=t: press(x)).grid(row=r,column=c,padx=5,pady=5)

    tk.Button(frame,text="Clear",width=15,command=clear_entry).grid(row=5,column=0,columnspan=3)

# ---------- RECEIPT ----------
def receipt(t, amt):
    user = atm.get_user()
    messagebox.showinfo("Receipt", f"""
===== ATM RECEIPT =====
Name    : {user['name']}
Type    : {t}
Amount  : {format_money(amt)}
Balance : {format_money(user['balance'])}
Date    : {current_time()}
=======================
""")

# ---------- MAIN ----------
def main_menu():
    clear()
    title("ATM SYSTEM")

    tk.Button(root,text="Create Account",width=30,command=create_screen).pack(pady=8)
    tk.Button(root,text="Login",width=30,
              command=lambda: card_swipe_animation(login_screen)).pack(pady=8)
    tk.Button(root,text="ATM Management",width=30,command=admin_login).pack(pady=8)
    tk.Button(root,text="Exit",width=30,command=root.destroy).pack(pady=8)

# ---------- CREATE ----------
def create_screen():
    clear()
    title("Create Account")

    label("Name"); name=tk.Entry(root); name.pack()
    label("PIN"); pin=tk.Entry(root,show="*"); pin.pack(); keypad(pin)
    label("Balance"); bal=tk.Entry(root); bal.pack()

    def submit():
        card = atm.create_user(name.get(), pin.get(), int(bal.get()))

        result = tk.Toplevel(root)
        result.title("Card Created")
        result.geometry("400x200")
        result.configure(bg="black")

        tk.Label(result, text="Card Created Successfully", fg="cyan", bg="black",
                 font=("Arial", 14, "bold")).pack(pady=10)

        entry = tk.Entry(result, font=("Arial", 14), justify="center")
        entry.pack(pady=10)
        entry.insert(0, card)

        def copy_card():
            result.clipboard_clear()
            result.clipboard_append(card)
            result.update()
            messagebox.showinfo("Copied", "Card number copied!")

        tk.Button(result, text="Copy Card Number", command=copy_card).pack(pady=5)
        tk.Button(result, text="OK", command=result.destroy).pack(pady=5)

        speak(f"Welcome {name.get()}")

    tk.Button(root,text="Create",command=submit).pack(pady=5)
    tk.Button(root,text="Back",command=main_menu).pack()

# ---------- LOGIN ----------
def login_screen():
    clear()
    title("Login")

    label("Card"); card=tk.Entry(root); card.pack()
    label("PIN"); pin=tk.Entry(root,show="*"); pin.pack(); keypad(pin)

    def login():
        if atm.login(card.get(), pin.get()):
            speak(f"Welcome {atm.get_user()['name']}")
            user_menu()
        else:
            messagebox.showerror("Error","Invalid")

    tk.Button(root,text="Login",command=login).pack(pady=5)
    tk.Button(root,text="Back",command=main_menu).pack()

# ---------- USER ----------
def user_menu():
    clear()
    title("Dashboard")

    tk.Button(root,text="Balance",width=30,
              command=lambda: messagebox.showinfo("Balance", format_money(atm.get_balance()))).pack(pady=5)
    tk.Button(root,text="Deposit",width=30,command=deposit_screen).pack(pady=5)
    tk.Button(root,text="Withdraw",width=30,command=withdraw_screen).pack(pady=5)
    tk.Button(root,text="Statement",width=30,command=statement_screen).pack(pady=5)
    tk.Button(root,text="Show Graph",width=30,command=lambda: show_graph(atm.users)).pack(pady=5)
    tk.Button(root,text="Show Pie Chart",width=30,command=lambda: show_pie_chart(atm.cash)).pack(pady=5)
    tk.Button(root,text="Logout",width=30,command=main_menu).pack(pady=5)

# ---------- DEPOSIT ----------
def deposit_screen():
    clear()
    title("Deposit")

    label("Enter Amount")
    amt=tk.Entry(root); amt.pack()

    def do():
        val=int(amt.get())
        atm.deposit(val)
        messagebox.showinfo("Success","Your money is deposited 💰")
        speak("Your money is deposited")
        receipt("Deposit", val)

    tk.Button(root,text="Submit",command=do).pack(pady=5)
    tk.Button(root,text="Back",command=user_menu).pack()

# ---------- WITHDRAW ----------
def withdraw_screen():
    clear()
    title("Withdraw")

    label("Enter Amount")
    amt=tk.Entry(root); amt.pack()

    def do():
        val=int(amt.get())
        if atm.withdraw(val):

            load = loading_bar()
            load.destroy()

            popup = tk.Toplevel(root)
            tk.Label(popup,text="💸 Cash is counting...").pack()

            anim = cash_animation()

            withdraw_sound()

            anim.destroy()
            popup.destroy()

            messagebox.showinfo("Success","Collect your cash 💸")
            speak("Please collect your cash")
            receipt("Withdraw", val)
        else:
            messagebox.showerror("Error","Insufficient Balance")

    tk.Button(root,text="Submit",command=do).pack(pady=5)
    tk.Button(root,text="Back",command=user_menu).pack()

# ---------- STATEMENT ----------
def statement_screen():
    user = atm.get_user()
    win = tk.Toplevel(root)
    txt = tk.Text(win)
    txt.pack()

    for t in user["transactions"]:
        txt.insert("end", f"{t['date']} | {t['type']} | {format_money(t['amount'])} | Bal: {format_money(t['balance_after'])}\n")

# ---------- ADMIN ----------
def admin_login():
    clear()
    title("Admin Login")

    label("Username"); u=tk.Entry(root); u.pack()
    label("Password"); p=tk.Entry(root,show="*"); p.pack()

    def login():
        if u.get()==ADMIN_USER and p.get()==ADMIN_PASS:
            admin_panel()
        else:
            messagebox.showerror("Error","Invalid")

    tk.Button(root,text="Login",command=login).pack()
    tk.Button(root,text="Back",command=main_menu).pack()

def admin_panel():
    clear()
    title("ATM MANAGEMENT")

    tk.Button(root,text="Show Cash",command=show_cash).pack(pady=5)
    tk.Button(root,text="Add Cash",command=add_cash).pack(pady=5)
    tk.Button(root,text="Back",command=main_menu).pack()

def show_cash():
    txt=""
    for n,c in atm.cash.items():
        txt += f"₹{n}: {c}\n"
    messagebox.showinfo("ATM Cash", txt)

def add_cash():
    clear()
    title("Add Cash")

    entries={}
    for n in atm.cash:
        label(f"₹{n}")
        e=tk.Entry(root); e.pack()
        entries[n]=e

    def add():
        for n,e in entries.items():
            try:
                atm.cash[n]+=int(e.get())
            except:
                pass
        save_data(ATM_FILE, atm.cash)
        messagebox.showinfo("Done","Cash Added")
        admin_panel()

    tk.Button(root,text="Add",command=add).pack()
    tk.Button(root,text="Back",command=admin_panel).pack()

# ---------- START ----------
main_menu()
root.mainloop()
